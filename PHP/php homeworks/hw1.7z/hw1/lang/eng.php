<?php

return [
    '#jan#' => 'January',
    '#feb#' => 'February',
    '#march#' => 'March',
    '#apr#' => 'April',
    '#may#' => 'May',
    '#june#' => 'June',
    '#july#' => 'July',
    '#aug#' => 'August',
    '#sep#' => 'September',
    '#oct#' => 'October',
    '#nov#' => 'November',
    '#dec#' => 'December'
];