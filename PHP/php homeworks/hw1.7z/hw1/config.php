<?php

return [
    'lang' => 'ua',
];